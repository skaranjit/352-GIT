#include <iostream>
using namespace std;
class JosephusException {
	public:
		JosephusException(){
            x = "asd";
        };
		
	private:
		string x;
};