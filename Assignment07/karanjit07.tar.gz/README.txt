Name: Suman Karanjit
Date: March 31, 2020
Assignment 07 : Joshephus problem using Circular queue.

Time to Complete: 20 hrs.

Description:
    This program will read names from a file and add to the circular queue. it will go through the circular queue and solve the joshepus problem and print out the surviror. 
    At last it will print out the names from queue in alphabetical asscending order.


Files Edited: CircularQueue.h, CircularQueue.cpp, main.cpp;